
#pragma once

void MQ_Initialize();
void MQ_Quit();
void MQ_Cleanup();
