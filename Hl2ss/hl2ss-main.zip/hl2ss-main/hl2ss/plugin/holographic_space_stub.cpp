
void HolographicSpace_EnableMarker(bool enable)
{
    (void)enable;
}
