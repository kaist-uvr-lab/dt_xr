
#pragma once

#include "configuration.h"

#define UNITY_EXPORT extern "C" __declspec(dllexport)
