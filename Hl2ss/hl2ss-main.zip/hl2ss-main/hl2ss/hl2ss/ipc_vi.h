
#pragma once

void VI_Initialize();
void VI_Quit();
void VI_Cleanup();
