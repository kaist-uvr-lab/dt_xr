
#pragma once

void RC_Initialize();
void RC_Quit();
void RC_Cleanup();
