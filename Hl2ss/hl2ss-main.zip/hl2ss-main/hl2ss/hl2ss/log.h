
#pragma once

void ShowMessage(const char* format, ...);
void ShowMessage(const wchar_t* format, ...);
