
#pragma once

void SM_Initialize();
void SM_Quit();
void SM_Cleanup();
