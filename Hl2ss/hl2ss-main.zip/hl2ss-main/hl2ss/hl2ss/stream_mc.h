
#pragma once

void MC_Initialize();
void MC_Quit();
void MC_Cleanup();
