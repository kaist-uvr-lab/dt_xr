
#pragma once

void RM_Initialize();
void RM_Quit();
void RM_Cleanup();
