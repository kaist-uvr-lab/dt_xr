
#pragma once

void SU_Initialize();
void SU_Quit();
void SU_Cleanup();
